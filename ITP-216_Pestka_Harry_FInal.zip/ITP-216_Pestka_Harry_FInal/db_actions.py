import sqlite3 as sl
import pandas as pd

# Define the database file name
db = "club_games.db"

def create_table():
    """
    Creates the table for the club_games dataset in the SQLite database.
    """
    conn = sl.connect(db)
    curs = conn.cursor()

    # Define the schema for the club_games table
    stmt = """
    CREATE TABLE IF NOT EXISTS club_games (
        game_id INT PRIMARY KEY,
        club_id INT,
        own_goals INT,
        own_position INT,
        own_manager_name VARCHAR(255),
        opponent_id INT,
        opponent_goals INT,
        opponent_position INT,
        opponent_manager_name VARCHAR(255),
        hosting VARCHAR(10),
        is_win BOOLEAN
    );
    """
    curs.execute(stmt)
    conn.commit()
    conn.close()

def store_data(fn):
    """
    Reads the CSV file and inserts its data into the club_games table.
    :param fn: Filepath to the CSV file.
    """
    conn = sl.connect(db)
    curs = conn.cursor()

    # Read the CSV using pandas
    df = pd.read_csv(fn)

    # Iterate through rows and insert data into the database
    for _, row in df.iterrows():
        stmt = """
        INSERT OR IGNORE INTO club_games (
            game_id, club_id, own_goals, own_position, own_manager_name,
            opponent_id, opponent_goals, opponent_position, opponent_manager_name,
            hosting, is_win
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        curs.execute(stmt, (
            row['game_id'], row['club_id'], row['own_goals'], row['own_position'], row['own_manager_name'],
            row['opponent_id'], row['opponent_goals'], row['opponent_position'], row['opponent_manager_name'],
            row['hosting'], row['is_win']
        ))

    conn.commit()
    conn.close()


def query_data(query):
    """
    Executes a query and returns the results as a pandas DataFrame.
    :param query: SQL query string.
    :return: pandas DataFrame with the query results.
    """
    conn = sl.connect(db)
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df


def main():
    # 1. Create the table
    create_table()

    # 2. Insert data from the CSV into the table
    store_data("club_gamesClean.csv")

    # 3. Query the data for testing
    print(query_data("SELECT * FROM club_games LIMIT 5"))


if __name__ == "__main__":
    main()