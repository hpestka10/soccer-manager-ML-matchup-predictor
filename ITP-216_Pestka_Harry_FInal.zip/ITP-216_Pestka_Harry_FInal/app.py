# Harry Pestka, pestka@usc.edu
# ITP 216, Fall 2024
# Section: 32046
# Final Project
import uuid
import matplotlib.pyplot as plt
import pandas as pd
import io
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import os
import random
from flask import Flask, redirect, render_template, request, session, url_for, send_file
import sqlite3 as sl
import matplotlib
matplotlib.use("Agg")  # Set non-interactive backend

app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
db = "club_games.db"

@app.route("/")
def home():
    """
    Render the home page with dropdowns for selecting managers.
    """
    conn = sl.connect(db)
    managers = pd.read_sql_query("SELECT DISTINCT own_manager_name FROM club_games", conn)["own_manager_name"].tolist()
    conn.close()
    return render_template("home.html", managers=managers)


@app.route("/submit_managers", methods=["POST"])
def submit_managers():
    manager1 = request.form["manager1"]
    manager2 = request.form["manager2"]
    home_manager = request.form["home_manager"]

    # Get career stats for both managers
    manager1_stats = get_manager_career_stats(manager1)
    manager2_stats = get_manager_career_stats(manager2)

    # URLs for manager plots
    manager1_plot_url = url_for("serve_plot", manager_name=manager1)
    manager2_plot_url = url_for("serve_plot", manager_name=manager2)

    # Include plot URLs in the manager info
    manager1_info = {**manager1_stats, "plot_url": manager1_plot_url}
    manager2_info = {**manager2_stats, "plot_url": manager2_plot_url}

    # Calculate head-to-head stats
    head_to_head = head_to_head_stats(manager1, manager2)

    # Pass head_to_head data to the template
    return render_template(
        "result.html",
        manager1_info=manager1_info,
        manager2_info=manager2_info,
        home_manager=home_manager,
        prediction=None,
        head_to_head=head_to_head  # Fixed: Add this line
    )


@app.route("/predict_game", methods=["POST"])
def predict_game():
    """
    Predict the outcome of a game between two managers and store the result in the database.
    """
    manager1 = request.form["manager1"]
    manager2 = request.form["manager2"]
    home_manager = request.form["home_manager"]

    # Get career stats for both managers
    manager1_stats = get_manager_career_stats(manager1)
    manager2_stats = get_manager_career_stats(manager2)

    # Predict scoreline
    home_goals, away_goals = predict_scoreline(manager1, manager2, home_manager)

    # Determine the home and away team names
    home_team = manager1 if home_manager == "manager1" else manager2
    away_team = manager2 if home_manager == "manager1" else manager1

    # Format the result
    result = f"Predicted scoreline: {home_team} {home_goals} - {away_goals} {away_team}"

    # Store the predicted result into the database
    store_predicted_game(home_team, away_team, home_goals, away_goals, home_manager)

    # URLs for manager plots
    manager1_plot_url = url_for("serve_plot", manager_name=manager1)
    manager2_plot_url = url_for("serve_plot", manager_name=manager2)

    # Include plot URLs in the manager info
    manager1_info = {**manager1_stats, "plot_url": manager1_plot_url}
    manager2_info = {**manager2_stats, "plot_url": manager2_plot_url}

    # h2h record
    head_to_head = head_to_head_stats(manager1, manager2)
    return render_template(
        "result.html",
        manager1_info=manager1_info,
        manager2_info=manager2_info,
        home_manager=home_manager,
        prediction=result,
        head_to_head=head_to_head
    )


@app.route("/plot/<manager_name>")
def serve_plot(manager_name):
    """
    Serve the manager's stats plot as an image.
    """
    img = plot_combined_stats(manager_name)
    return send_file(img, mimetype="image/png")


def db_get_managers():
    """
    Retrieve a list of distinct manager names from the database.
    """
    conn = sl.connect(db)
    managers = pd.read_sql_query("SELECT DISTINCT own_manager_name FROM club_games", conn)["own_manager_name"].tolist()
    conn.close()
    return managers


def get_manager_career_stats(manager_name):
    """
    Retrieve detailed career stats for a given manager.
    """
    conn = sl.connect(db)
    query = """
        SELECT own_manager_name AS name, 
               COUNT(*) AS games_played, 
               SUM(is_win) AS wins, 
               SUM(own_goals) AS total_goals_scored, 
               SUM(opponent_goals) AS total_goals_conceded
        FROM club_games 
        WHERE own_manager_name = ? 
        GROUP BY own_manager_name
    """
    stats = pd.read_sql_query(query, conn, params=(manager_name,)).to_dict(orient="records")[0]
    conn.close()
    return stats


def calculate_goals_stats(manager_name):
    """
    Calculate average goals scored and conceded per game for the given manager.
    """
    conn = sl.connect("club_games.db")
    query = """
        SELECT 
            AVG(own_goals) AS avg_goals_scored,
            AVG(opponent_goals) AS avg_goals_conceded
        FROM club_games
        WHERE own_manager_name = ?
    """
    stats = pd.read_sql_query(query, conn, params=(manager_name,)).to_dict(orient="records")[0]
    conn.close()
    return stats


def predict_scoreline(manager1, manager2, home_manager):
    """
    Predict a scoreline for a match between two managers using Linear Regression.
    Includes model evaluation and historical data.
    """
    conn = sl.connect(db)
    query = """
        SELECT hosting, own_goals, opponent_goals, opponent_position, own_position
        FROM club_games 
        WHERE own_manager_name IN (?, ?)
    """
    data = pd.read_sql_query(query, conn, params=(manager1, manager2))
    conn.close()

    # Feature engineering
    data['target_goals'] = data.apply(
        lambda row: row['own_goals'] if row['hosting'] == 'Home' else row['opponent_goals'], axis=1)
    data['is_home'] = data['hosting'].map({'Home': 1, 'Away': 0})
    data['opponent_strength'] = data['opponent_position']
    data['team_strength'] = data['own_position']

    X = data[['is_home', 'opponent_strength', 'team_strength']].values
    y = data['target_goals'].values

    # Train/Test Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train the model
    model = LinearRegression()
    model.fit(X_train, y_train)

    # Evaluate the model
    y_pred = model.predict(X_test)
    print(f"Mean Squared Error: {mean_squared_error(y_test, y_pred):.2f}")
    print(f"R² Score: {r2_score(y_test, y_pred):.2f}")

    # Predict goals for home and away managers
    home_pred = model.predict([[1, random.randint(1, 20), random.randint(1, 20)]])[0]
    away_pred = model.predict([[0, random.randint(1, 20), random.randint(1, 20)]])[0]

    # Add Gaussian noise
    home_goals = max(0, round(home_pred + random.gauss(0, 1)))
    away_goals = max(0, round(away_pred + random.gauss(0, 1)))

    return home_goals, away_goals


def head_to_head_stats(manager1, manager2):
    """
    Retrieve historical head-to-head stats between two managers.
    """
    conn = sl.connect(db)
    query = """
        SELECT 
            SUM(CASE WHEN own_manager_name = ? AND is_win = 1 THEN 1 ELSE 0 END) AS manager1_wins,
            SUM(CASE WHEN own_manager_name = ? AND is_win = 1 THEN 1 ELSE 0 END) AS manager2_wins,
            COUNT(*) AS total_matches
        FROM club_games
        WHERE own_manager_name IN (?, ?) AND opponent_manager_name IN (?, ?)
    """
    result = pd.read_sql_query(query, conn, params=(manager1, manager2, manager1, manager2, manager2, manager1))
    conn.close()

    if not result.empty:
        return result.to_dict(orient="records")[0]
    return {"manager1_wins": 0, "manager2_wins": 0, "total_matches": 0}


def plot_combined_stats(manager_name):
    """
    Generate a histogram for goals scored and conceded at home and away for the given manager.
    Returns the plot as BytesIO.
    """
    conn = sl.connect("club_games.db")

    # Query to calculate average goals scored and conceded for home and away games
    query = """
        SELECT 
            hosting,
            AVG(own_goals) AS avg_goals_scored,
            AVG(opponent_goals) AS avg_goals_conceded
        FROM club_games
        WHERE own_manager_name = ?
        GROUP BY hosting
    """
    df = pd.read_sql_query(query, conn, params=(manager_name,))
    conn.close()

    # Prepare data for the histogram
    labels = df["hosting"]  # Home/Away labels
    goals_scored = df["avg_goals_scored"]
    goals_conceded = df["avg_goals_conceded"]
    x = range(len(labels))  # X positions for groups

    # Create the histogram
    fig, ax = plt.subplots(figsize=(8, 6))

    # Add bars for scored and conceded goals
    ax.bar(x, goals_scored, width=0.4, label="Avg Goals Scored", color="blue", align="center")
    ax.bar([pos + 0.4 for pos in x], goals_conceded, width=0.4, label="Avg Goals Conceded", color="red", align="center")

    # Set labels, title, and legend
    ax.set_xticks([pos + 0.2 for pos in x])
    ax.set_xticklabels(labels)
    ax.set_title(f"Goals Scored vs Conceded (Home vs Away) - {manager_name}")
    ax.set_xlabel("Hosting")
    ax.set_ylabel("Average Goals")
    ax.legend()
    ax.grid(axis="y", linestyle="--", alpha=0.7)

    # Save plot to BytesIO
    img = io.BytesIO()
    plt.tight_layout()
    plt.savefig(img, format="png")
    plt.close(fig)
    img.seek(0)
    return img


def store_predicted_game(home_manager, away_manager, home_goals, away_goals, home_manager_flag):
    """
    Store the predicted game result into the database.
    """
    conn = sl.connect("club_games.db")
    curs = conn.cursor()

    # Generate a unique game_id using uuid
    game_id = str(uuid.uuid4())

    # Determine the hosting flag and winner
    hosting = "Home" if home_manager_flag == "manager1" else "Away"
    is_win_home = 1 if home_goals > away_goals else 0

    # Insert the game into the database
    stmt = """
    INSERT INTO club_games (
        game_id, club_id, own_goals, own_position, own_manager_name,
        opponent_id, opponent_goals, opponent_position, opponent_manager_name,
        hosting, is_win
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """

    # Insert for the home manager
    curs.execute(stmt, (
        game_id,
        random.randint(1, 100),  # Placeholder club_id for demo purposes
        home_goals,
        random.randint(1, 20),  # Placeholder position
        home_manager,
        random.randint(1, 100),  # Placeholder opponent_id
        away_goals,
        random.randint(1, 20),  # Placeholder position
        away_manager,
        hosting,
        is_win_home
    ))

    conn.commit()
    conn.close()


if __name__ == "__main__":
    app.secret_key = os.urandom(12)
    app.run(debug=True)